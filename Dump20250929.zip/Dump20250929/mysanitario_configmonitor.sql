-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mysanitario
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configmonitor`
--

DROP TABLE IF EXISTS `configmonitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configmonitor` (
  `idconfigmonitor` int NOT NULL AUTO_INCREMENT,
  `immaginesfondo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ximmaginesfondo` int NOT NULL,
  `yimmaginesfondo` int NOT NULL,
  `boximmagini` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `hboximmagini` int NOT NULL,
  `wboximmagini` int NOT NULL,
  `xboximmagini` int NOT NULL,
  `yboximmagini` int NOT NULL,
  `boxvideo` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `hboxvideo` int NOT NULL,
  `wboxvideo` int NOT NULL,
  `xboxvideo` int NOT NULL,
  `yboxvideo` int NOT NULL,
  `boxmeteo` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `hboxmeteo` int NOT NULL,
  `wboxmeteo` int NOT NULL,
  `xboxmeteo` int NOT NULL,
  `yboxmeteo` int NOT NULL,
  `urlboxmeteo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `boxnews` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `hboxnews` int NOT NULL,
  `wboxnews` int NOT NULL,
  `xboxnews` int NOT NULL,
  `yboxnews` int NOT NULL,
  `urlboxnews` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `boxchiamati` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `hboxchiamati` int NOT NULL,
  `wboxchiamati` int NOT NULL,
  `xboxchiamati` int NOT NULL,
  `yboxchiamati` int NOT NULL,
  `fontboxchiamati` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `boldboxchiamati` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `numatuttoschermo` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fontnumatuttoschermo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `boldnumatuttoschermo` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `fontturnonumatuttoschermo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `boldturnonumatuttoschermo` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `imgsfondonumatuttoschermo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`idconfigmonitor`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configmonitor`
--

LOCK TABLES `configmonitor` WRITE;
/*!40000 ALTER TABLE `configmonitor` DISABLE KEYS */;
INSERT INTO `configmonitor` VALUES (4,'uploads/monitor/1753032610_monitor-new.jpg',3840,2160,'1',890,1614,66,1256,'0',0,0,0,0,'0',0,0,0,0,'','0',191,3458,18,2600,'https://myeliminacode.acwild.eu/appOffline/news/news-lazio/','1',789,1526,125,415,'Impact','0','0','','0','','0','');
/*!40000 ALTER TABLE `configmonitor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29 17:48:19
