-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mysanitario
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configturnimonitor`
--

DROP TABLE IF EXISTS `configturnimonitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configturnimonitor` (
  `idconfigturnimonitor` int NOT NULL AUTO_INCREMENT,
  `idturno` int NOT NULL,
  `fontturno` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sizeturno` int NOT NULL,
  `boldturno` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `coloreturno` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `xturno` int NOT NULL,
  `yturno` int NOT NULL,
  `hturno` int NOT NULL,
  `wturno` int NOT NULL,
  `fontcontatore` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sizecontatore` int NOT NULL,
  `boldcontatore` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `colorecontatore` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `xcontatore` int NOT NULL,
  `ycontatore` int NOT NULL,
  `hcontatore` int NOT NULL,
  `wcontatore` int NOT NULL,
  `fontpostazione` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sizepostazione` int NOT NULL,
  `boldpostazione` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `colorepostazione` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `xpostazione` int NOT NULL,
  `ypostazione` int NOT NULL,
  `hpostazione` int NOT NULL,
  `wpostazione` int NOT NULL,
  PRIMARY KEY (`idconfigturnimonitor`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configturnimonitor`
--

LOCK TABLES `configturnimonitor` WRITE;
/*!40000 ALTER TABLE `configturnimonitor` DISABLE KEYS */;
INSERT INTO `configturnimonitor` VALUES (13,23,'Impact',130,'1','#5bb1e5',3574,273,207,268,'Impact',130,'1','#080808',2718,210,355,593,'Impact',130,'1','#000000',1949,218,353,552),(18,28,'Impact',130,'1','#5bb1e5',3568,657,219,272,'Impact',130,'1','#000000',2714,600,360,595,'Impact',130,'1','#000000',1955,612,340,551),(19,29,'Impact',130,'1','#5bb1e5',3585,1098,213,249,'Impact',130,'1','#080808',2710,1000,331,607,'Impact',130,'1','#000000',1955,1006,345,558),(20,30,'Impact',130,'1','#5bb1e5',3579,1455,222,263,'Impact',130,'1','#080808',2714,1411,333,611,'Impact',130,'1','#000000',1951,1417,336,579);
/*!40000 ALTER TABLE `configturnimonitor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29 17:48:17
