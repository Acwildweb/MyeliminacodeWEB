-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mysanitario
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `configturnitotem`
--

DROP TABLE IF EXISTS `configturnitotem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configturnitotem` (
  `idconfigturnitotem` int NOT NULL AUTO_INCREMENT,
  `idconfigtotem` int NOT NULL,
  `idturno` int NOT NULL,
  `fontturno` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `sizeturno` int NOT NULL,
  `boldturno` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `coloreturno` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `xturno` int NOT NULL,
  `yturno` int NOT NULL,
  `hturno` int NOT NULL,
  `wturno` int NOT NULL,
  `sfondobutton` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`idconfigturnitotem`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configturnitotem`
--

LOCK TABLES `configturnitotem` WRITE;
/*!40000 ALTER TABLE `configturnitotem` DISABLE KEYS */;
INSERT INTO `configturnitotem` VALUES (1,1,23,'Impact',20,'1','#000000',16,323,277,1019,'uploads/monitor/1753026603_turno-a.png'),(18,1,31,'Impact',35,'1','#000000',72,845,104,892,'uploads/monitor/1751370236_turnoE.png'),(19,1,30,'Impact',25,'1','#000000',15,1239,277,1018,'uploads/monitor/1753027035_turno-d.png'),(20,1,29,'Impact',25,'1','#000000',15,933,277,1017,'uploads/monitor/1753027018_turno-c.png'),(21,1,28,'Impact',25,'1','#000000',16,629,275,1018,'uploads/monitor/1753026997_turno-b.png');
/*!40000 ALTER TABLE `configturnitotem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29 17:48:18
