-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: mysanitario
-- ------------------------------------------------------
-- Server version	8.4.6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `operazioni_giorni`
--

DROP TABLE IF EXISTS `operazioni_giorni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operazioni_giorni` (
  `pk_opgio` int NOT NULL,
  `id_operazione` int NOT NULL,
  `giorno` int NOT NULL,
  `ora_inizio` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ora_fine` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`pk_opgio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operazioni_giorni`
--

LOCK TABLES `operazioni_giorni` WRITE;
/*!40000 ALTER TABLE `operazioni_giorni` DISABLE KEYS */;
INSERT INTO `operazioni_giorni` VALUES (634,25,0,'0900','1100',''),(635,25,1,'0650','1850',''),(636,25,2,'0650','1850',''),(637,25,3,'0650','1850',''),(638,25,4,'0650','1850',''),(639,25,5,'0650','1850',''),(640,25,6,'0650','1330',''),(647,27,1,'0650','1200',''),(648,27,2,'0650','1200',''),(649,27,3,'0650','1200',''),(650,27,4,'0650','1200',''),(651,27,5,'0650','1200',''),(652,27,6,'0650','1150',''),(653,26,1,'0650','1850',''),(654,26,2,'0650','1850',''),(655,26,3,'0650','1850',''),(656,26,4,'0650','1850',''),(657,26,5,'0650','1850',''),(658,26,6,'0650','1320',''),(659,29,1,'1300','1850',''),(660,29,2,'1300','1850',''),(661,29,3,'1300','1850',''),(662,29,4,'1300','1850',''),(663,29,5,'1300','1850',''),(664,29,6,'0650','1320','');
/*!40000 ALTER TABLE `operazioni_giorni` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-29 17:48:18
